# Flowkenstein

Tableau BPMN 2.0 gratuit, en français, avec une page d’accueil.

Ouvrez Accueil_Flowkenstein.html pour accéder au site, ou Flowkenstein.html pour dessiner.
Aucune installation ni dépendance réseau n’est nécessaire.

## Sources

- src/editor.html : code de l’éditeur avant intégration de la bibliothèque.
- src/home.html : code de la page d’accueil.
- vendor/ : bpmn-js, styles, police et licence.
- build.cjs : génère les pages autonomes avec Node.js (node build.cjs).

Les fichiers HTML à la racine sont prêts à utiliser. Pour héberger le site,
servez ce dossier statiquement avec Accueil_Flowkenstein.html comme page d’entrée.
Pour activer le téléchargement des sources depuis l’accueil, placez aussi
l’archive Flowkenstein-sources.zip à côté de cette page.

La sauvegarde utilise le stockage local du navigateur. Elle ne remplace pas
une copie du fichier BPMN. Le code original est sous licence MIT ; bpmn-js
conserve sa licence et son logo obligatoires.
